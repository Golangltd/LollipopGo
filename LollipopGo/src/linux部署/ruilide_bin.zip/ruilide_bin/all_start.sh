./start_Login.sh
sleep 2
./start_gateway.sh
sleep 2
./start_db.sh
sleep 4
./start_global.sh
sleep 3
./start_Gm.sh
