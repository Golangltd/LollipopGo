ps -ef | grep LollipopGo*
